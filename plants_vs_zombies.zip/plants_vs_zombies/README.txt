XP Game Pack - ready for the Wine XP runner
Contains classic Windows XP built-in games + a console number-guess game.
All .exe are 32-bit PE and run under the prepared Windows XP Wine prefix.
Drop any additional .exe into this folder; the runner will find them.
