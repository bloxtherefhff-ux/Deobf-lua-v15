@echo off
echo XP Game Pack
echo.
echo 1. Minesweeper
echo 2. Solitaire
echo 3. FreeCell
echo 4. Spider
echo 5. Hearts
echo 6. Number Guess
echo.
set /p c=Choose (1-6): 
if "%c%"=="1" start winmine.exe
if "%c%"=="2" start sol.exe
if "%c%"=="3" start freecell.exe
if "%c%"=="4" start spider.exe
if "%c%"=="5" start mshearts.exe
if "%c%"=="6" start GuessGame.exe
